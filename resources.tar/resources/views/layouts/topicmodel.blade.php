<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        <link href="{{ asset('css/app.css') }}" rel="stylesheet">
        <title>Jichannel</title>
        <link rel="icon" href="{{ asset('img/logo.png') }}">
        <style>
            header{
                width:193px; 
                height:170px;
                margin:0 auto;
                display: flex;
                justify-content: space-between;
                align-items:center;
            }
            body{
                margin:0;
                padding:0;
                background-color:#cccccc;
                color:#333333;
                font-size:15px;
                line-height:2;
            }
            form,a,img,p,h1,thead,tbody{
                text-align:center;
                margin:0 auto;
            }
            footer{
                text-align:center;
                color:#ffffff;
                padding: 20px 0;
            }
            .gmap {
                height: 0;
                overflow: hidden;
                padding-bottom: 56.25%;
                position: relative;
                }
            .gmap iframe {
                position: absolute;
                left: 0;
                top: 0;
                height: 100%;
                width: 100%;
            }
        </style>
    </head>
    <body>
        <header>
            <a href = "{{ url('/') }}"><img src="{{ asset('img/logo.png') }}" width="193" height="130"></img></a>
        </header>
        
        <!--フラッシュメッセージを表示-->
        @if (session('message'))
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                {{ session('message')}}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>    
            </div>
        @endif
        
        <!--ナビゲーションバー-->
        <ul class="nav justify-content-center nav-tabs nav-justified">
            <li class="nav-item"><a class="nav-link" href="{{ url('/') }}"><font color="white" size="5">ホーム</font></a></li>
            <li class="nav-item"><a class="nav-link" href="https://docs.google.com/forms/d/e/1FAIpQLSd5p1zRmFXgHXYSOU3vl1mVEhEIZCbc-c0lE5DhslHoB02guw/viewform?usp=sf_link"><font color="white" size="5">お問い合わせ</font></a></li>
            <li class="nav-item"><a class="nav-link" href="{{url('tos')}}"><font color="white" size="5">利用規約</font></a></li>
        </ul>
            
        <!-- バリデーションエラーの表示に使用-->
        @include('common.errors')
        
        <div class='container'>
            <!--投稿一覧を表示-->
            @if (count($nodles) > 0)
                <h1>{{ $page_name }}</h1>
                <center><h3>{{ $page_desc}}</h3></center>
                
                <div class="card-group">
                    <?php
                        $i=0;
                        $l =0;
                    ?>
                    @forelse($nodles as $nodle)
                    @if ($nodle->page == $page_num)
                    @if( !empty($nodle->item_img )  )
                        <?php
                            $l = $l +1;
                        ?>
                        @if($l == 6)
                            @break
                        @endif
                        <div class="card" style="max-width: 10rem;">
                            <img class="card-img-top" src="upload/{{$nodle->item_img}}" alt="photo">
                            <div class="card-body">
                                <center><h4 class="card-title">投稿画像</h4></center>
                            </div>
                        </div>    
                    @endif    
                    @endif
                    @endforeach
                </div>
                <main class="py-4">
                @yield('content')
                </main>
                        @foreach ($nodles as $nodle)
                        @if ($nodle->page == $page_num)
                            <?php
                                $i = $i + 1;
                            ?>    
                            <center><p>{{ $i}} {{ $nodle->user_name }}   {{ $nodle->created_at }}</p></center>
                            <p><center>{{ $nodle->post }}</center></p>
                            <center><img src="upload/{{$nodle->item_img}}" width="100"></center>
                        @endif
                    @endforeach
            @endif
            
            <!--投稿機能-->
            <form enctype="multipart/form-data" action={{ $update_url }} method="POST" class="form-horizontal">
                @csrf
                <div class="mb-3 row">
                    <label class="form-label col-sm-2 col-form-label" for="user_name">ユーザーネーム</label>
                    <div class="col-sm-6">
                        <input type="text" name="user_name" class="form-control" placeholder="ユーザーネームを入力">
                    </div>
                </div>
                
                <div class="mb-3 row">
                    <label class="form-label col-sm-2 col-form-label" for="post">コメント</label>
                    <div class="col-sm-6">
                        <textarea class="form-control" name="post" id="post" rows="3" placeholder="素敵なコメントを書く"></textarea>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label" for="item_img">画像を選択</label>
                    <input type="file" class="from-contorl" name="item_img">
                </div>
        
                <button type="submit" class="btn btn-primary">投稿</button>
            
                <input type="hidden" name="page" value="{{ $page_num }}">
                <input type="hidden" name="page_name" value="{{ $page_name }}">
                <input type="hidden" name="page_url" value="{{ $page_url }}">
                <input type="hidden" name="page_desc" value="{{ $page_desc }}">
            </form>

            </div>
        </div>    
        <footer><small>Copyright ©2022 群馬の二ちゃん All Rights Reserved.</small></footer>
        
    </body>
</html>
