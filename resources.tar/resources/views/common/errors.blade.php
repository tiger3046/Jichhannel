@if (count($errors) > 0)
    <!-- Form Error List -->
    <div class="alert alert-danger">
        <center><div><strong>入力した文字を修正してください。</strong></div></center> 
        <div>
            <ul>
            @foreach ($errors->all() as $error)
                <center><li>{{ $error }}</li></center>
            @endforeach
            </ul>
        </div>
    </div>
@endif