@extends('layouts.topicmodel')
@section('content')
<?php
    $page_num = 1;
    $page_name = "群馬三大二郎はどこなのか？";
    $page_url = "topicone";
    $page_desc ="群馬県内には多数の二郎系ラーメンが存在する。その中でも群馬県の3大二郎といえばどこなのかを徹底議論したい。";
    $update_url = "/topicone/update";
?>
@endsection