@extends('layouts.topicmodel')
@section('content')
        <?php
            $page_num = 5;
            $page_name = "ラーメンダイサン";
            $page_url = "topicfive";
            $page_desc ="ラーメンダイサンは二郎系には珍しいトマトの乗った二郎系ラーメンである。「二郎にトマト」、この是非を問いたい。";
            $update_url = "/topicfive/update";
        ?>
<div class="gmap">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3215.2040478806784!2d139.1822609155475!3d36.3073584029851!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x601ee8bfd8d65555%3A0x74be6a1e5a452411!2z44Op44O844Oh44Oz44OA44Kk44K144Oz!5e0!3m2!1sja!2sjp!4v1648444878201!5m2!1sja!2sjp" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></center>
</div>
@endsection                