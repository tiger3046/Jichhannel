@extends('layouts.topicmodel')
@section('content')
<?php
    $page_num = 3;
    $page_name = "ラーメン滋悟郎";
    $page_url = "topicthree";
    $page_desc ="ラーメン滋悟郎は群馬県では数本の指に入るとも称される名店である。日夜人がその店先に並び
    列をなす。このラーメン滋悟郎についてあつく語り合いたい。";
    $update_url = "/topicthree/update";
?>
<div class="gmap">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3214.4264301814605!2d139.32061851554772!3d36.32621360193558!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x601ee08ae5618b31%3A0x10f65a1daa10c939!2z44Op44O844Oh44Oz5ruL5oKf6YOO!5e0!3m2!1sja!2sjp!4v1648444790080!5m2!1sja!2sjp" width="100％" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>
@endsection