@extends('layouts.topicmodel')
@section('content')
<?php
            $page_num = 2;
            $page_name = "ラーメン大蛇";
            $page_url = "topictwo";
            $page_desc ="毎日ように人を集めその店に前に列をつくる人気店ラーメン大蛇。高崎随一と名高い名店を共に語りあいたい。";
            $update_url = "/topictwo/update";
?>
<div class="gmap">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d51443.23474664684!2d139.00816218372324!3d36.307403906468636!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x601e8d5b6676e625%3A0x77c584abd710fde8!2z6Ieq5a626KO944Op44O844Oh44OzIOWkp-iAhQ!5e0!3m2!1sja!2sjp!4v1648444507607!5m2!1sja!2sjp" width="100％" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>
@endsection