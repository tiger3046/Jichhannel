@extends('layouts.topicmodel')
@section('content')
<?php
            $page_num = 6;
            $page_name = "群馬県の隠れた二郎系の名店といえば";
            $page_url = "topicsix";
            $page_desc ="他のジロリアンに是非おすすめしたい隠れた名店を広く集めたい。";
            $update_url = "/topicsix/update";
?>
@endsection