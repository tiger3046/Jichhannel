@extends('layouts.topicmodel')
@section('content')
    <?php
        $page_num = 4;
        $page_name = "群馬で一番はラーメン二郎なのか？";
        $page_url = "topicfour";
        $page_desc ="群馬県にはすべての二郎系ラーメンのアダムとイブともいえるラーメン二郎が存在する。この群馬県において頂点はやはりその元祖なのか？その是非を問いたい。";
        $update_url = "/topicfour/update";
    ?>
    <center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d51387.11695220609!2d139.03594067910154!3d36.39238149999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x601ef3f72550681b%3A0x4e6162f748fcaacb!2z44Op44O844Oh44Oz5LqM6YOOIOWJjeapi-WNg-S7o-eUsOeUuuW6lw!5e0!3m2!1sja!2sjp!4v1648444258460!5m2!1sja!2sjp" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></center>
@endsection