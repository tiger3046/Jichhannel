<!DOCTYPE html>
<html lang="ja">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        <link href="{{ asset('css/app.css') }}" rel="stylesheet">
        <title>Jichannel</title>
        <link rel="icon" href="{{ asset('img/logo.png') }}">
        <style>
            header{
                width:193px; 
                height:170px;
                margin:0 auto;
                display: flex;
                justify-content: space-between;
                align-items:center;
            }
            body{
                margin:0;
                padding:0;
                background-color:#cccccc;
                color:#333333;
                font-size:15px;
                line-height:2;
            }
            form,a,img,p,h1{
                text-align:center;
                margin:0 auto;
            }
            footer{
                text-align:center;
                color:#ffffff;
                padding: 20px 0;
            }
            ul,li{
                text-align:center;
            }
            video{
                max-width: 80%;
            }
        </style>
    </head>
    <body>
        <header>
            <h2>二ちゃんねる</h2>
        </header>
        
        <ul class="nav justify-content-center nav-tabs nav-justified">
            <li class="nav-item"><a class="nav-link" href="{{ url('/') }}"><font color="white" size="5">ホーム</font></a></li>
            <li class="nav-item"><a class="nav-link" href="https://docs.google.com/forms/d/e/1FAIpQLSd5p1zRmFXgHXYSOU3vl1mVEhEIZCbc-c0lE5DhslHoB02guw/viewform?usp=sf_link"><font color="white" size="5">お問い合わせ</font></a></li>
            <li class="nav-item"><a class="nav-link" href="{{url('tos')}}"><font color="white" size="5">利用規約</font></a></li>
        </ul>
        
        <center>
            <video controls="controls" width="1700" height="750">
                <source src="{{ asset('img/concept.mp4') }}"  controls autoplay playsinline loop >
            </video>
        </center>
            
            <h1>群馬県のすべてのジロリアン達よ、集え</h1>
            
            <center>
            @if (count($nodles) > 0)
                @foreach ($nodles as $nodle)
                    <center>    
                        <div class="main">
                            <div class="card" style="max-width :25rem">
                                <a href="{{ url( $nodle->page_url )}}">
                                <img class="card-img-top" src="{{ asset('img/logo.png') }}">
                                </a>
                                <div class="card-body">
                                <h4 class="card-title">{{$nodle->page_name}}</h4>
                                <p class="card-text">{{$nodle->page_desc}}</p>
                                <a href="{{ url( $nodle->page_url )}}" class="btn btn-primary">スレッドへ</a>
                            </div>
                        </div>
                    </center>
                @endforeach
                {{ $nodles->links() }}
            @endif
        </div>
    
        <footer><small>Copyright ©2022 群馬の二ちゃん All Rights Reserved.</small></footer>
    
    </body>
</html>
