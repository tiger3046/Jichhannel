<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Nodle;
use Validator;

class NodlesController extends Controller
{
    public function index(Request $request){
        $nodles= Nodle::groupBy('page')
        ->orderBy('page' ,'desc')
        ->simplePaginate(5);
        return view('nodles', [
            'nodles' => $nodles
        ]); 
    }
    
    public function topicone(Request $request){
        $nodles = Nodle::orderBy('created_at', 'asc')->get();
        return view('topicone', [
            'nodles' => $nodles
        ]);
    } 
    
    public function topiconeupdate(Request $request){
        $validator = Validator::make($request->all(), [
        'user_name' => 'required|min:1|max:50',
        'post' => 'required|min:3|max:255',
        ]);
    //バリデーション:エラー
        if ($validator->fails()) {
            return redirect('/topicone')
                ->withInput()
                ->withErrors($validator);
        }
    
        $file = $request->file('item_img');
        if( !empty($file) ){                //fileが空かチェック
          $filename = $file->getClientOriginalName();   //ファイル名を取得
          $move = $file->move('./upload/',$filename);  //ファイルを移動：パスが“./upload/”の場合もあるCloud9
        }else{
          $filename = "";
        }
        
        //データ登録
        $nodles = new Nodle;
        $nodles->user_name=$request->user_name;
        $nodles->post= $request->post;
        $nodles->item_img = $filename;
        $nodles->page= $request->page;
        $nodles->page_name= $request->page_name;
        $nodles->page_url= $request->page_url;
        $nodles->page_desc= $request->page_desc;
        $nodles->save();
        return redirect('/topicone')->with('message' ,'投稿が完了しました。');
    }
    
    public function topictwo(Request $request){
        
        $nodles = Nodle::orderBy('created_at', 'asc')->get();
        return view('topictwo', [
        'nodles' => $nodles
        ]);
    }
    
    public function topictwoupdate(Request $request){
        $validator = Validator::make($request->all(), [
        'user_name' => 'required|min:1|max:50',
        'post' => 'required|min:3|max:255',
        ]);
        //バリデーション:エラー
        if ($validator->fails()) {
            return redirect('/topictwo')
                ->withInput()
                ->withErrors($validator);
        }
    
        $file = $request->file('item_img');
        if( !empty($file) ){                //fileが空かチェック
          $filename = $file->getClientOriginalName();   //ファイル名を取得
          $move = $file->move('./upload/',$filename);  //ファイルを移動：パスが“./upload/”の場合もあるCloud9
        }else{
          $filename = "";
        }
        
        //データ登録
        $nodles = new Nodle;
        $nodles->user_name=$request->user_name;
        $nodles->post= $request->post;
        $nodles->item_img = $filename;
        $nodles->page= $request->page;
        $nodles->page_name= $request->page_name;
        $nodles->page_url= $request->page_url;
        $nodles->page_desc= $request->page_desc;
        $nodles->save();
        return redirect('/topictwo')->with('message' ,'投稿が完了しました。');
        
    }
    
    public function topicthree(Request $request){
        $nodles = Nodle::orderBy('created_at', 'asc')->get();
        return view('topicthree', [
        'nodles' => $nodles
        ]);
    }
    
    public function topicthreeupdate(Request $request){
        $validator = Validator::make($request->all(), [
        'user_name' => 'required|min:1|max:50',
        'post' => 'required|min:3|max:255',
        ]);
        //バリデーション:エラー
        if ($validator->fails()) {
            return redirect('/topicthree')
                ->withInput()
                ->withErrors($validator);
        }
    
        $file = $request->file('item_img');
        if( !empty($file) ){                //fileが空かチェック
          $filename = $file->getClientOriginalName();   //ファイル名を取得
          $move = $file->move('./upload/',$filename);  //ファイルを移動：パスが“./upload/”の場合もあるCloud9
        }else{
          $filename = "";
        }
        
        //データ登録
        $nodles = new Nodle;
        $nodles->user_name=$request->user_name;
        $nodles->post= $request->post;
        $nodles->item_img = $filename;
        $nodles->page= $request->page;
        $nodles->page_name= $request->page_name;
        $nodles->page_url= $request->page_url;
        $nodles->page_desc= $request->page_desc;
        $nodles->save();
        return redirect('/topicthree')->with('message' ,'投稿が完了しました。');
        
    }
    
    public function topicfour(Request $request){
        
        $nodles = Nodle::orderBy('created_at', 'asc')->get();
        return view('topicfour', [
        'nodles' => $nodles
        ]);
    }
    
    public function topicfourupdate(Request $request){
        $validator = Validator::make($request->all(), [
        'user_name' => 'required|min:1|max:50',
        'post' => 'required|min:3|max:255',
        ]);
        //バリデーション:エラー
        if ($validator->fails()) {
            return redirect('/topicfour')
                ->withInput()
                ->withErrors($validator);
        }
    
        $file = $request->file('item_img');
        if( !empty($file) ){                //fileが空かチェック
          $filename = $file->getClientOriginalName();   //ファイル名を取得
          $move = $file->move('./upload/',$filename);  //ファイルを移動：パスが“./upload/”の場合もあるCloud9
        }else{
          $filename = "";
        }
        
        //データ登録
        $nodles = new Nodle;
        $nodles->user_name=$request->user_name;
        $nodles->post= $request->post;
        $nodles->item_img = $filename;
        $nodles->page= $request->page;
        $nodles->page_name= $request->page_name;
        $nodles->page_url= $request->page_url;
        $nodles->page_desc= $request->page_desc;
        $nodles->save();
        return redirect('/topicfour')->with('message' ,'投稿が完了しました。');
        
    }
    
    public function topicfive(Request $request){
        
        $nodles = Nodle::orderBy('created_at', 'asc')->get();
        return view('topicfive', [
        'nodles' => $nodles
        ]);
    }
    
    public function topicfiveupdate(Request $request){
        $validator = Validator::make($request->all(), [
        'user_name' => 'required|min:1|max:50',
        'post' => 'required|min:3|max:255',
        ]);
        //バリデーション:エラー
        if ($validator->fails()) {
            return redirect('/topicfive')
                ->withInput()
                ->withErrors($validator);
        }
    
        $file = $request->file('item_img');
        if( !empty($file) ){                //fileが空かチェック
          $filename = $file->getClientOriginalName();   //ファイル名を取得
          $move = $file->move('./upload/',$filename);  //ファイルを移動：パスが“./upload/”の場合もあるCloud9
        }else{
          $filename = "";
        }
        
        //データ登録
        $nodles = new Nodle;
        $nodles->user_name=$request->user_name;
        $nodles->post= $request->post;
        $nodles->item_img = $filename;
        $nodles->page= $request->page;
        $nodles->page_name= $request->page_name;
        $nodles->page_url= $request->page_url;
        $nodles->page_desc= $request->page_desc;
        $nodles->save();
        return redirect('/topicfive')->with('message' ,'投稿が完了しました。');
        
    }
    public function topicsix(Request $request){
        
        $nodles = Nodle::orderBy('created_at', 'asc')->get();
        return view('topicsix', [
        'nodles' => $nodles
        ]);
    }
    
    public function topicsixupdate(Request $request){
        $validator = Validator::make($request->all(), [
        'user_name' => 'required|min:1|max:50',
        'post' => 'required|min:3|max:255',
        ]);
        //バリデーション:エラー
        if ($validator->fails()) {
            return redirect('/topicsix')
                ->withInput()
                ->withErrors($validator);
        }
    
        $file = $request->file('item_img');
        if( !empty($file) ){                //fileが空かチェック
          $filename = $file->getClientOriginalName();   //ファイル名を取得
          $move = $file->move('./upload/',$filename);  //ファイルを移動：パスが“./upload/”の場合もあるCloud9
        }else{
          $filename = "";
        }
        
        //データ登録
        $nodles = new Nodle;
        $nodles->user_name=$request->user_name;
        $nodles->post= $request->post;
        $nodles->item_img = $filename;
        $nodles->page= $request->page;
        $nodles->page_name= $request->page_name;
        $nodles->page_url= $request->page_url;
        $nodles->page_desc= $request->page_desc;
        $nodles->save();
        return redirect('/topicsix')->with('message' ,'投稿が完了しました。');
        
    }
}
