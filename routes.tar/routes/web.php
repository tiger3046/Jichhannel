<?php
use App\Models\Nodle;
use Illuminate\Http\Request;
use App\Http\Controllers\NodlesController;

Route::get('/', 'App\Http\Controllers\NodlesController@index');

Route::get('/tos', function () {
    return view('tos'); 
});

Route::post('/topicone', 'App\Http\Controllers\NodlesController@topicone');

Route::get('/topicone', 'App\Http\Controllers\NodlesController@topicone');

Route::post('/topicone/update', 'App\Http\Controllers\NodlesController@topiconeupdate');


Route::post('/topictwo', 'App\Http\Controllers\NodlesController@topictwo');

Route::get('/topictwo', 'App\Http\Controllers\NodlesController@topictwo');

Route::post('/topictwo/update', 'App\Http\Controllers\NodlesController@topictwoupdate');


Route::post('/topicthree', 'App\Http\Controllers\NodlesController@topicthree');

Route::get('/topicthree', 'App\Http\Controllers\NodlesController@topicthree');

Route::post('/topicthree/update', 'App\Http\Controllers\NodlesController@topicthreeupdate');


Route::post('/topicfour', 'App\Http\Controllers\NodlesController@topicfour');

Route::get('/topicfour', 'App\Http\Controllers\NodlesController@topicfour');

Route::post('/topicfour/update', 'App\Http\Controllers\NodlesController@topicfourupdate');


Route::post('/topicfive', 'App\Http\Controllers\NodlesController@topicfive');

Route::get('/topicfive', 'App\Http\Controllers\NodlesController@topicfive');

Route::post('/topicfive/update', 'App\Http\Controllers\NodlesController@topicfiveupdate');


Route::post('/topicsix', 'App\Http\Controllers\NodlesController@topicsix');

Route::get('/topicsix', 'App\Http\Controllers\NodlesController@topicsix');

Route::post('/topicsix/update', 'App\Http\Controllers\NodlesController@topicsixupdate');



